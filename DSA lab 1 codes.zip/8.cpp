#include<iostream>
using namespace std;
class Circle {
private:
    double radius;
public:
    Circle(double r){
        radius=r;
    }
    double getArea() {
        return 3.14159 * radius * radius;
    }
};
int main() {
    Circle* circlePtr;
    Circle circle(5.0);
    circlePtr = &circle;
    cout << "Area of the circle is : " << circlePtr->getArea() << endl;
    return 0;
}
