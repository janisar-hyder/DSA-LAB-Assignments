#include <iostream>
using namespace std;
class CS {
public:
    string name;
    int age;
};
int main() {
    CS *Ptr = new CS[3];

    Ptr[0].name = "Janisar";
    Ptr[0].age = 20;

    Ptr[1].name = "Zamar";
    Ptr[1].age = 20;

    Ptr[2].name = "Rafay";
    Ptr[2].age = 21;

    for(int i=0; i<3; i++) {
        cout<< "Name: " << Ptr[i].name << ", Age: " << Ptr[i].age << endl;
    }

    delete[] Ptr;
    return 0;
}
