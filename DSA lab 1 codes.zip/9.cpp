#include<iostream>
using namespace std;
struct Student {
    int id;
    string name;
}stu;

int main() {
    Student *ptr = &stu;
    ptr->id = 47;
    ptr->name = "Janisar";
    std::cout << "Student ID: " << ptr->id << ", Name: " << ptr->name <<endl;
    return 0;
}
