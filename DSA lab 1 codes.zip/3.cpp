#include<iostream>
using namespace std;
int main() {
    int arr[] = {1, 2, 3, 4, 5};
    int *ptr = arr;
    cout<<"Value at ptr:"<<*ptr<<endl;
    ptr++;
    cout << "Value at ptr after increment: "<<*ptr<<endl;
    return 0;
}
