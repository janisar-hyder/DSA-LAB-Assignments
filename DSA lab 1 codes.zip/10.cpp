#include<iostream>
using namespace std;
int main() {
    char str[] = "Hey there! I am janisar";
    char *ptr = str;
    while (*ptr != '\0') {
        cout << *ptr;
        ptr++;
    }
    cout<<endl;
    return 0;
}
