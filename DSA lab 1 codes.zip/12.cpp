#include <iostream>
using namespace std;
class Animal {
public:
    void speak() {
        cout << "Animal speaks" << endl;
    }
};
class Dog : public Animal {
public:
    void speak() {
        cout<<"Dog bark"<<endl;
    }
};
int main() {
    Animal *Ptr = new Dog;
    Ptr->speak();
    Dog *Ptr1 = new Dog;
    Ptr1->speak();
    return 0;
}
