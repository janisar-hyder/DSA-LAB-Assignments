#include<iostream>
using namespace std;
int main() {
    int a,b,c;
    cout<<"Enter the 1st num: ";
    cin>>a;
    cout<<"Enter the 2nd num: ";
    cin>>b;
    c=a*b;
    int *ptr1=&a;
    int *ptr2=&b;
    int *ptr3=&c;
    cout<<"multiplication of a and b is =  "<<*ptr3;
    return 0;
}
