#include <iostream>
using namespace std;
class My {
public:
    string name;
    int age;
};
int main() {
    My *ptr = new My;
    ptr->name = "Janisar";
    ptr->age = 20;
    cout << "Name: " << ptr->name << ", Age: " << ptr->age << endl;
    delete ptr;
    return 0;
}
