#include<iostream>
using namespace std;
int main() {
    cout<<"printing  the value of x"<<endl;
    int x = 5;
    int *ptr;
    ptr=&x;
    cout<<*ptr;
    return 0;
}
