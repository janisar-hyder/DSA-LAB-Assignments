#include<iostream>
using namespace std;
int main() {
    float a,b,c;
    cout<<"Enter the 1st num: ";
    cin>>a;
    cout<<"Enter the 2nd num: ";
    cin>>b;
    c=a/b;
    float *ptr1=&a;
    float *ptr2=&b;
    float *ptr3=&c;
    cout<<"Division of a and b is =  "<<*ptr3;
    return 0;
}
